<?php
session_start();
require_once 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];
    
    // Delete from inventory first (due to foreign key constraint)
    $conn->query("DELETE FROM inventory WHERE product_id = $product_id");
    
    // Then delete product
    $conn->query("DELETE FROM products WHERE product_id = $product_id");
    
    $_SESSION['message'] = "Product deleted successfully";
    header("Location: beranda_admin.php");
    exit();
}