-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2025 at 01:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `min_stock` int(11) NOT NULL DEFAULT 10,
  `location` varchar(50) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `product_id`, `stock`, `min_stock`, `location`, `last_updated`) VALUES
(10, 13, 1, 10, NULL, '2025-07-16 11:19:57'),
(14, 17, 10, 10, NULL, '2025-07-16 03:14:14'),
(15, 18, 0, 10, NULL, '2025-07-16 11:28:28'),
(16, 19, 7, 10, NULL, '2025-07-16 11:22:05'),
(18, 21, 20, 10, NULL, '2025-07-14 12:35:26'),
(19, 22, 10, 10, NULL, '2025-07-14 12:35:47'),
(20, 23, 19, 10, NULL, '2025-07-16 11:33:14'),
(21, 24, 29, 10, NULL, '2025-07-16 11:33:14'),
(22, 8, 3, 10, NULL, '2025-07-15 21:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` enum('food','drink','snack','other') NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `date_added` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `category`, `price`, `description`, `created_at`, `updated_at`, `date_added`) VALUES
(8, 'sate ayam', 'food', 20000.00, '', '2025-06-30 06:56:56', '2025-07-15 21:14:00', '2025-06-30'),
(13, 'Kwetiaw Goreng', 'food', 25000.00, '', '2025-07-08 00:26:27', '2025-07-14 10:34:52', '2025-07-08'),
(17, 'ayam goreng', 'food', 20000.00, '', '2025-07-14 12:33:28', '2025-07-14 12:33:28', '2025-07-14'),
(18, 'mie goreng', 'food', 10000.00, '', '2025-07-14 12:34:24', '2025-07-14 12:34:24', '2025-07-14'),
(19, 'Ko Kue Goreng', 'food', 18000.00, '', '2025-07-14 12:34:54', '2025-07-14 12:42:33', '2025-07-14'),
(21, 'Kroket', 'food', 3000.00, '', '2025-07-14 12:35:26', '2025-07-14 12:35:26', '2025-07-14'),
(22, 'soto', 'food', 15000.00, '', '2025-07-14 12:35:47', '2025-07-14 12:35:47', '2025-07-14'),
(23, 'pecel lele', 'food', 18000.00, '', '2025-07-14 12:36:05', '2025-07-14 12:36:05', '2025-07-14'),
(24, 'Lele Bakar', 'food', 20000.00, '', '2025-07-14 12:41:16', '2025-07-14 12:41:16', '2025-07-14');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_type` enum('walkin','member') DEFAULT 'walkin',
  `total_amount` decimal(10,2) NOT NULL CHECK (`total_amount` >= 0),
  `discount` decimal(10,2) DEFAULT 0.00 CHECK (`discount` >= 0),
  `status` enum('completed','cancelled') DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `change_amount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `user_id`, `customer_type`, `total_amount`, `discount`, `status`, `created_at`, `paid_amount`, `change_amount`) VALUES
(29, 1, 'walkin', 20000.00, 0.00, 'completed', '2025-07-16 03:14:14', 20000.00, 0.00),
(30, 2, 'walkin', 25000.00, 0.00, 'completed', '2025-07-16 03:27:01', 30000.00, 5000.00),
(32, 2, 'walkin', 75000.00, 0.00, 'completed', '2025-07-16 11:19:57', 150000.00, 75000.00),
(35, 1, 'walkin', 18000.00, 0.00, 'completed', '2025-07-16 11:22:05', 70000.00, 52000.00),
(36, 1, 'walkin', 5000.00, 50.00, 'completed', '2025-07-16 11:28:28', 20000.00, 15000.00),
(38, 1, 'walkin', 38000.00, 0.00, 'completed', '2025-07-16 11:33:14', 50000.00, 12000.00);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_items`
--

CREATE TABLE `transaction_items` (
  `item_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL CHECK (`quantity` > 0),
  `price_per_item` decimal(10,2) NOT NULL DEFAULT 0.00,
  `price` decimal(10,2) NOT NULL CHECK (`price` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_items`
--

INSERT INTO `transaction_items` (`item_id`, `transaction_id`, `product_id`, `quantity`, `price_per_item`, `price`) VALUES
(34, 29, 17, 1, 20000.00, 0.00),
(35, 30, 13, 1, 25000.00, 0.00),
(36, 32, 13, 3, 25000.00, 0.00),
(37, 35, 19, 1, 18000.00, 0.00),
(38, 36, 18, 1, 10000.00, 0.00),
(40, 38, 24, 1, 20000.00, 0.00),
(41, 38, 23, 1, 18000.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','kasir') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$d0rOLwmKke6udJi5fPhjW.pTU6mmAKivsv6yu.otj62NHXL/kJnWG', 'admin'),
(2, 'kasir1', '$2y$10$CYsSwDmDfCNXte3bD4heceNAGSYVF5i60R3hqeA4S5M6yyG6klJou', 'kasir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `transaction_id` (`transaction_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `transaction_items`
--
ALTER TABLE `transaction_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD CONSTRAINT `transaction_items_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`transaction_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaction_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
