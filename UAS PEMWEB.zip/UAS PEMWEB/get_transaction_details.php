<?php
session_start();
require_once 'database.php';

header('Content-Type: application/json');

if (!isset($_GET['transaction_id'])) {
    echo json_encode(['success' => false, 'message' => 'Transaction ID is required.']);
    exit();
}

$transactionId = $_GET['transaction_id'];

try {
    $stmt = $conn->prepare("SELECT t.*, u.username as cashier_name 
                            FROM transactions t 
                            LEFT JOIN users u ON t.user_id = u.user_id 
                            WHERE t.transaction_id = ?");
    $stmt->bind_param("i", $transactionId);
    $stmt->execute();
    $result = $stmt->get_result();
    $transactionDetails = $result->fetch_assoc();

    if (!$transactionDetails) {
        echo json_encode(['success' => false, 'message' => 'Transaction not found.']);
        exit();
    }

    $stmt = $conn->prepare("SELECT ti.*, p.name as product_name 
                            FROM transaction_items ti 
                            JOIN products p ON ti.product_id = p.product_id 
                            WHERE ti.transaction_id = ?");
    $stmt->bind_param("i", $transactionId);
    $stmt->execute();
    $result = $stmt->get_result();
    $transactionItems = $result->fetch_all(MYSQLI_ASSOC);

    $response = [
        'success' => true,
        'transaction' => $transactionDetails,
        'items' => $transactionItems
    ];

    echo json_encode($response);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error fetching transaction details: ' . $e->getMessage()]);
}