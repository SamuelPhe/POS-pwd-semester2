<?php
session_start();
require_once 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        header("Location: login.php?error=Username dan password harus diisi!");
        exit();
    }
    
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $query);
    
    if (!$result) {
        die("Query Error: " . mysqli_error($conn));
    }
    
    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        
        
        file_put_contents('login_debug.log', 
            "User: " . $user['username'] . "\n" .
            "Password Hash: " . $user['password'] . "\n" .
            "Input Password: " . $password . "\n" .
            "Verification: " . (password_verify($password, $user['password']) ? 'Success' : 'Failed') . "\n\n",
            FILE_APPEND);
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            error_log("User ID set in session: " . $_SESSION['user_id'], 0);
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            
            switch ($user['role']) {
                case 'admin':
                    header("Location: beranda_admin.php");
                    exit();
                case 'kasir':
                    header("Location: beranda_kasir.php");
                    exit();
                default:
                    header("Location: login.php?error=Role tidak valid");
                    exit();
            }
        }
    }
    
    header("Location: login.php?error=Username atau password salah!");
    exit();
}